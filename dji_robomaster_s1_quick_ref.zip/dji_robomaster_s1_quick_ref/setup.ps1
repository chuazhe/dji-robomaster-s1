python get-pip.py
python -m pip install -r requirements.txt